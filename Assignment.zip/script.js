
const addItemForm = document.getElementById('add-item-form');
const itemInput = document.getElementById('item-input');
const shoppingList = document.getElementById('shopping-list');
let items = [];

function fetchItemsFromStorage() {
    const storedItems = localStorage.getItem('shoppingListItems');
    if (storedItems) {
        items = JSON.parse(storedItems);
    }
}

function saveItemsToStorage() {
    localStorage.setItem('shoppingListItems', JSON.stringify(items));
}

function renderShoppingList() {
    shoppingList.innerHTML = '';
    items.forEach((item, index) => {
        const listItem = document.createElement('li');
        listItem.innerHTML = `
            <input type="checkbox" id="item-${index}">
            <label for="item-${index}">${item}</label>
        `;
        shoppingList.appendChild(listItem);
    });
    saveItemsToStorage();
}

function handleFormSubmit(event) {
    event.preventDefault();
    const newItem = itemInput.value.trim();
    if (newItem !== '') {
        items.push(newItem);
        renderShoppingList();
        itemInput.value = '';
    }
}

addItemForm.addEventListener('submit', handleFormSubmit);

fetchItemsFromStorage();
renderShoppingList();
